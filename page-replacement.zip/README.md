# Page Replacement algorithms in JS

## Usage

-   nalezy posiadać zainstalowany npm
-   nastepnie wpisac 'npm i' aby zainstalowac paczki uzywane w projekcie
-   aby uruchomic program nalezy uzyc komendy 'npm start'

## Algorithms FIFO ,LRU, LFU, MFU
